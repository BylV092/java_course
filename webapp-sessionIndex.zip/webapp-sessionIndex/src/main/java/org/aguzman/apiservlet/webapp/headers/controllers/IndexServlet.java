package org.aguzman.apiservlet.webapp.headers.controllers;

import java.io.IOException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/index.html")
public class IndexServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Obtén el nombre completo del atributo en el objeto HttpServletRequest
        String nombreCompleto = (String) request.getServletContext().getAttribute("nombreCompleto");

        response.setContentType("text/html");
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h1>Nombre Completo:</h1>");
        response.getWriter().println("<p>" + nombreCompleto + "</p>");
        response.getWriter().println("</body></html>");
    }
}

