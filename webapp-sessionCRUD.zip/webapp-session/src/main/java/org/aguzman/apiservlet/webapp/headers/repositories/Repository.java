package org.aguzman.apiservlet.webapp.headers.repositories;

import org.aguzman.apiservlet.webapp.headers.models.Curso;

import java.sql.SQLException;
import java.util.List;

public interface Repository<T> {
    Curso crear(Curso curso);

    Curso obtener(int id);

    List<T> listar() throws SQLException;
    T porId(Long id) throws SQLException;
    void guardar(T t) throws SQLException;
    void eliminar(Long id) throws SQLException;

    Curso actualizar(Curso curso);

    void eliminar(int id);
}
