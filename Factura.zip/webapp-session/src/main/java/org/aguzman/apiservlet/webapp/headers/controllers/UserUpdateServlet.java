package org.aguzman.apiservlet.webapp.headers.controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/updateUser")
public class UserUpdateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recopila datos del formulario (id, username, password, name, email)
        int id = Integer.parseInt(request.getParameter("id"));
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String email = request.getParameter("email");

        // Realiza validación de datos (puedes agregar validaciones específicas aquí)
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            // Muestra un mensaje de error si el nombre de usuario o la contraseña están vacíos
            request.setAttribute("errorMessage", "Nombre de usuario y contraseña son obligatorios.");
            request.getRequestDispatcher("/listUsers").forward(request, response);
            return; // Detiene la ejecución del servlet
        }

        // Otras validaciones, como longitud del nombre, formato del correo, etc.
        // Puedes agregar validaciones específicas según tus necesidades.

        // Actualiza los datos del usuario en la base de datos
        User updatedUser = new User(id, username, password, name, email); // Suponiendo que tengas una clase User
        boolean userUpdated = UserService.updateUser(updatedUser); // Suponiendo que tengas un servicio para gestionar usuarios

        if (userUpdated) {
            // Redirige a la página de listado de usuarios con un mensaje de éxito
            request.setAttribute("successMessage", "Datos del usuario actualizados exitosamente.");
            request.getRequestDispatcher("/listUsers").forward(request, response);
        } else {
            // Muestra un mensaje de error en caso de fallo
            request.setAttribute("errorMessage", "Error al actualizar los datos del usuario. Inténtalo de nuevo.");
            request.getRequestDispatcher("/listUsers").forward(request, response);
        }
    }
}
