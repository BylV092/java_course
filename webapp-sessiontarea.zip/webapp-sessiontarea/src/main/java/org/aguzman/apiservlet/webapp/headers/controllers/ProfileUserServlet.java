package org.aguzman.apiservlet.webapp.headers.controllers;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/perfil-usuario")
public class ProfileUserServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String nombre = (String) session.getAttribute("nombre");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head><title>Perfil de Usuario</title></head>");
        out.println("<body>");
        out.println("<p>Nombre de usuario: " + (nombre != null ? nombre : "anónimo") + "</p>");
        out.println("<a href='/webapp-session-tarea5/index.jsp'>Volver a la página de inicio</a>");
        out.println("</body>");
        out.println("</html>");
    }
}
