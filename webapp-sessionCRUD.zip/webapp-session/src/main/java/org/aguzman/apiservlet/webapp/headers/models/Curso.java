package org.aguzman.apiservlet.webapp.headers.models;

public class Curso {
    public String getNombre() {
        return null;
    }

    public String getDescripcion() {
        return null;
    }

    public void setId(int anInt) {
    }

    public void setNombre(String nombre) {
    }

    public void setDescripcion(String descripcion) {
    }

    public int getId() {
        return 0;
    }
}
