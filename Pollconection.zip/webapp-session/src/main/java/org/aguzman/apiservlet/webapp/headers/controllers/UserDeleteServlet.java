package org.aguzman.apiservlet.webapp.headers.controllers;

import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/deleteUser")
public class UserDeleteServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recopila el ID del usuario a eliminar desde los parámetros de la solicitud
        String userIdParam = request.getParameter("userId");

        if (userIdParam != null && !userIdParam.isEmpty()) {
            try {
                // Convierte el ID del usuario a un entero
                int userId = Integer.parseInt(userIdParam);

                // Lógica para eliminar el usuario con el ID especificado de la base de datos
                // Debes implementar esta lógica según tu configuración de base de datos

                // Muestra un mensaje de éxito después de eliminar el usuario
                request.setAttribute("successMessage", "Usuario eliminado con éxito");
            } catch (NumberFormatException e) {
                // El parámetro del ID del usuario no es válido
                request.setAttribute("errorMessage", "Error al eliminar el usuario. ID no válido.");
            }
        } else {
            // El parámetro del ID del usuario no se proporcionó
            request.setAttribute("errorMessage", "Error al eliminar el usuario. ID no especificado.");
        }

        // Redirige a la página de listado de usuarios
        request.getRequestDispatcher("/listUsers.jsp").forward(request, response);
    }
}
