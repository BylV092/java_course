package org.aguzman.apiservlet.webapp.headers.listeners;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class NameCompleteListener implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        // Puedes configurar el nombre y apellido aquí o cargarlo desde una base de datos.
        String nombre = "Juan";
        String apellido = "Pérez";

        // Combinar nombre y apellido en un solo atributo
        String nombreCompleto = nombre + " " + apellido;

        // Almacenar el nombre completo en el contexto de la aplicación
        sce.getServletContext().setAttribute("nombreCompleto", nombreCompleto);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // Realiza las operaciones de limpieza si es necesario al detener la aplicación.
    }
}

