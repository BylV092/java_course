package org.aguzman.apiservlet.webapp.headers.controllers;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.aguzman.apiservlet.webapp.headers.repositories.CursoService;
import org.aguzman.apiservlet.webapp.headers.repositories.CursoServiceImpl;

import java.io.IOException;

@WebServlet("/curso-eliminar")
public class CursoEliminarServlet extends HttpServlet {
    private CursoService cursoService; // Inyecta el servicio a través del constructor

    public CursoEliminarServlet() {
        // Inicializa el servicio (puedes inyectarlo de forma adecuada según tu configuración)
        this.cursoService = new CursoServiceImpl(); // Asegúrate de inicializarlo correctamente.
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Obtén el ID del curso a eliminar desde la solicitud
        String idParam = request.getParameter("id"); // Suponiendo que el parámetro en la solicitud se llama "id"

        if (idParam != null && !idParam.isEmpty()) {
            try {
                int cursoId = Integer.parseInt(idParam);
                // Llama al servicio para eliminar el curso
                cursoService.eliminarCurso(cursoId);

                // Redirige a la página de lista de cursos o muestra un mensaje de éxito
                response.sendRedirect("lista-cursos.jsp"); // Cambia "lista-cursos.jsp" por la página adecuada
            } catch (NumberFormatException e) {
                e.printStackTrace();
                // Manejo de errores en caso de que el ID no sea un número válido
            }
        } else {
            // Manejo de errores en caso de que no se proporcione un ID válido
            response.sendRedirect("error.jsp"); // Redirige a una página de error
        }
    }
}
