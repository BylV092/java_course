package webappProducesFacturTarea15.Model;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

@Named
@RequestScoped
public class Cliente {
    private String nombre;
    private String email;
    private String apellidos;

    @PostConstruct
    public void init() {
        nombre = "NombrePredeterminado";
        email = "email@dominio.com";
        apellidos = "ApellidosPredeterminados";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
}

