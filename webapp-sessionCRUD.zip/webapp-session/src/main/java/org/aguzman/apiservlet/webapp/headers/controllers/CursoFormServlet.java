package org.aguzman.apiservlet.webapp.headers.controllers;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/curso-form")
public class CursoFormServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Configura la respuesta
        response.setContentType("text/html");

        // Carga la página JSP para el formulario de creación/actualización de cursos
        RequestDispatcher dispatcher = request.getRequestDispatcher("/curso-form.jsp");

        try {
            // Reenvía la solicitud a la página JSP
            dispatcher.forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            // Manejo de excepciones apropiado aquí.
        }
    }
}