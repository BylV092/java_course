package org.aguzman.apiservlet.webapp.headers.controllers;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/guardar-session")
public class SaveNameSessionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("nombre");

        if (nombre != null && !nombre.isEmpty()) {
            HttpSession session = request.getSession();
            session.setAttribute("nombre", nombre);
        }

        response.sendRedirect(request.getContextPath() + "/perfil-usuario");
    }
}
