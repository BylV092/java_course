package org.aguzman.apiservlet.webapp.headers.controllers;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.aguzman.apiservlet.webapp.headers.models.Carro;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/actualizar-carro")
public class UpdateCarServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        Carro carro = (Carro) request.getSession().getAttribute("carro");
        String[] eliminarIds = request.getParameterValues("eliminar");

        if (eliminarIds != null) {
            for (String id : eliminarIds) {
                int productoId = Integer.parseInt(id);
                carro.eliminarItem(productoId);
            }
        }


        // Obtén un mapa con las cantidades actualizadas desde los parámetros del formulario
        Map<Integer, Integer> cantidadesActualizadas = obtenerCantidadesActualizadas(request);

        // Actualiza las cantidades en el carrito
        carro.actualizarCantidades(cantidadesActualizadas);

        response.sendRedirect(request.getContextPath() + "/carro.jsp");
    }

    // Método para obtener un mapa de cantidades actualizadas desde los parámetros del formulario
    private Map<Integer, Integer> obtenerCantidadesActualizadas(HttpServletRequest request) {
        Map<Integer, Integer> cantidadesActualizadas = new HashMap<>();
        Enumeration<String> parameterNames = request.getParameterNames();

        while (parameterNames.hasMoreElements()) {
            String paramName = parameterNames.nextElement();
            if (paramName.startsWith("cantidad-")) {
                int productoId = Integer.parseInt(paramName.replace("cantidad-", ""));
                int nuevaCantidad = Integer.parseInt(request.getParameter(paramName));
                cantidadesActualizadas.put(productoId, nuevaCantidad);
            }
        }

        return cantidadesActualizadas;
    }
}

