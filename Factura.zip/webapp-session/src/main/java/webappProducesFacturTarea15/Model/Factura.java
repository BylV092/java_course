package webappProducesFacturTarea15.Model;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.List;

@Named
@RequestScoped
public class Factura {
    @Inject
    private Cliente cliente;

    private Integer folio;
    private String nombre;
    private List<LineaFactura> lineasFactura;

    @PostConstruct
    public void init() {
        folio = 12345;
        nombre = "Descripción de la factura";

        // Inyecta las líneas de factura utilizando el producer
        lineasFactura = ProducerResources.produceLineasFactura();
    }

    // Getters y setters
}
