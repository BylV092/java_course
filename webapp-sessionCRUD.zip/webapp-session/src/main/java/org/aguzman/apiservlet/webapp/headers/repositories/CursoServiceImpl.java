package org.aguzman.apiservlet.webapp.headers.repositories;

import org.aguzman.apiservlet.webapp.headers.models.Curso;

import java.sql.SQLException;
import java.util.List;

public class CursoServiceImpl implements CursoService {
    private Repository<Curso> cursoRepositorio; // Inyecta el repositorio a través del constructor.

    public CursoServiceImpl() {
        this.cursoRepositorio = cursoRepositorio;
    }


    @Override
    public Curso crearCurso(Curso curso) {
        return null;
    }

    @Override
    public Curso obtenerCurso(int id) {
        return cursoRepositorio.obtener(id);
    }

    @Override
    public List<Curso> listarCursos() throws SQLException {
        return cursoRepositorio.listar();
    }

    @Override
    public Curso actualizarCurso(Curso curso) {
        // Puedes agregar lógica de validación u otros procesos de negocio aquí.
        return cursoRepositorio.actualizar(curso);
    }

    @Override
    public void eliminarCurso(int id) {
        // Puedes agregar lógica de validación u otros procesos de negocio aquí.
        cursoRepositorio.eliminar(id);
    }
}
