package webappProducesFacturTarea15.Controller;

import java.io.IOException;
import jakarta.inject.Inject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import webappProducesFacturTarea15.Model.Factura;

@WebServlet("/factura")
public class FacturaController extends HttpServlet {
    @Inject
    private Factura factura;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Puedes configurar los datos necesarios antes de redirigir a la vista
        // Aquí puedes, por ejemplo, establecer atributos en la solicitud (request) para que la vista los muestre

        request.setAttribute("factura", factura);

        // Redirige a la vista factura.jsp
        request.getRequestDispatcher("/factura.jsp").forward(request, response);
    }
}

