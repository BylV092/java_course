package org.aguzman.apiservlet.webapp.headers.controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/createUser")
public class UserCreateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recopila datos del formulario (username, password, name, email)
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String email = request.getParameter("email");

        // Realiza validación de datos
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            // Muestra un mensaje de error si el nombre de usuario o la contraseña están vacíos
            request.setAttribute("errorMessage", "Nombre de usuario y contraseña son obligatorios.");
            request.getRequestDispatcher("/listUsers").forward(request, response);
            return; // Detiene la ejecución del servlet
        }

        // Crea un nuevo usuario en la base de datos
        User newUser = new User(username, password, name, email); // Suponiendo que tengas una clase User
        boolean userCreated = UserService.createUser(newUser); // Suponiendo que tengas un servicio para gestionar usuarios

        if (userCreated) {
            // Redirige a la página de listado de usuarios con un mensaje de éxito
            request.setAttribute("successMessage", "Usuario creado exitosamente.");
            request.getRequestDispatcher("/listUsers").forward(request, response);
        } else {
            // Muestra un mensaje de error en caso de fallo
            request.setAttribute("errorMessage", "Error al crear el usuario. Inténtalo de nuevo.");
            request.getRequestDispatcher("/listUsers").forward(request, response);
        }
    }
}
