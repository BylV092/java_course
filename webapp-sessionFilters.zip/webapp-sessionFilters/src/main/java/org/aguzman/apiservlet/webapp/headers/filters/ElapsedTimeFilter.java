package org.aguzman.apiservlet.webapp.headers.filters;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.annotation.WebInitParam;
import java.io.IOException;

public class ElapsedTimeFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Inicialización del filtro, si es necesaria.
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        long inicio = System.currentTimeMillis(); // Tiempo de inicio

        // Antes de continuar con la solicitud, puedes realizar tareas adicionales aquí.

        chain.doFilter(request, response); // Continuar con la solicitud

        long fin = System.currentTimeMillis(); // Tiempo de término
        long tiempoTranscurrido = fin - inicio;

        System.out.println("El tiempo de carga de la página es de " + tiempoTranscurrido + " milisegundos.");

        // Después de la solicitud, puedes realizar tareas adicionales aquí.

    }

    @Override
    public void destroy() {
        // Liberación de recursos, si es necesaria.
    }
}

