package org.aguzman.apiservlet.webapp.headers.repositories;

import org.aguzman.apiservlet.webapp.headers.models.Curso;

import java.sql.SQLException;
import java.util.List;

public interface CursoService {
    Curso crearCurso(Curso curso);
    Curso obtenerCurso(int id);
    List<Curso> listarCursos() throws SQLException;
    Curso actualizarCurso(Curso curso);
    void eliminarCurso(int id);
}
