package org.aguzman.apiservlet.webapp.headers.controllers;
import java.io.IOException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/cambiar-color")
public class CambiarColorServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtiene el valor del parámetro "color" del formulario
        String color = request.getParameter("color");

        // Crea o actualiza la cookie llamada "color"
        Cookie colorCookie = new Cookie("color", color);
        colorCookie.setMaxAge(365 * 24 * 60 * 60); // Duración de la cookie en segundos (1 año)
        response.addCookie(colorCookie);

        // Redirige a la vista index.jsp para refrescar los cambios de la cookie
        response.sendRedirect(request.getContextPath() + "/index.jsp");
    }
}

