package webappProducesFacturTarea15.Model;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import webappProducesFacturTarea15.Model.LineaFactura;

import java.util.Arrays;
import java.util.List;

@ApplicationScoped
public class ProducerResources {
    @Produces
    public static List<LineaFactura> produceLineasFactura() {
        // Crea una lista de LineaFactura con datos de ejemplo
        return Arrays.asList(
                new LineaFactura(100, 2, "Producto 1"),
                new LineaFactura(50, 3, "Producto 2"),
                new LineaFactura(75, 1, "Producto 3")
        );
    }
}
