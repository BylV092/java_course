package org.aguzman.apiservlet.webapp.headers.repositories;

import org.aguzman.apiservlet.webapp.headers.models.Curso;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CRUDRepositoryImpl implements Repository<Curso> {
    private Connection conexion; // Debes establecer una conexión válida a la base de datos.

    // Constructor que recibe la conexión a la base de datos
    public CRUDRepositoryImpl(Connection conexion) {
        this.conexion = conexion;
    }

    @Override
    public Curso crear(Curso curso) {
        String consulta = "INSERT INTO cursos (nombre, descripcion) VALUES (?, ?)";
        try (PreparedStatement statement = conexion.prepareStatement(consulta, PreparedStatement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, curso.getNombre());
            statement.setString(2, curso.getDescripcion());
            statement.executeUpdate();

            ResultSet generatedKeys = statement.getGeneratedKeys();
            if (generatedKeys.next()) {
                curso.setId(generatedKeys.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejo de excepciones apropiado aquí.
        }
        return curso;
    }

    @Override
    public Curso obtener(int id) {
        Curso curso = null;
        String consulta = "SELECT * FROM cursos WHERE id = ?";
        try (PreparedStatement statement = conexion.prepareStatement(consulta)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                curso = new Curso();
                curso.setId(resultSet.getInt("id"));
                curso.setNombre(resultSet.getString("nombre"));
                curso.setDescripcion(resultSet.getString("descripcion"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejo de excepciones apropiado aquí.
        }
        return curso;
    }

    @Override
    public List<Curso> listar() {
        List<Curso> cursos = new ArrayList<>();
        String consulta = "SELECT * FROM cursos";
        try (PreparedStatement statement = conexion.prepareStatement(consulta)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Curso curso = new Curso();
                curso.setId(resultSet.getInt("id"));
                curso.setNombre(resultSet.getString("nombre"));
                curso.setDescripcion(resultSet.getString("descripcion"));
                cursos.add(curso);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejo de excepciones apropiado aquí.
        }
        return cursos;
    }

    @Override
    public Curso porId(Long id) throws SQLException {
        return null;
    }

    @Override
    public void guardar(Curso curso) throws SQLException {

    }

    @Override
    public void eliminar(Long id) throws SQLException {

    }

    @Override
    public Curso actualizar(Curso curso) {
        String consulta = "UPDATE cursos SET nombre = ?, descripcion = ? WHERE id = ?";
        try (PreparedStatement statement = conexion.prepareStatement(consulta)) {
            statement.setString(1, curso.getNombre());
            statement.setString(2, curso.getDescripcion());
            statement.setInt(3, curso.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejo de excepciones apropiado aquí.
        }
        return curso;
    }

    @Override
    public void eliminar(int id) {
        String consulta = "DELETE FROM cursos WHERE id = ?";
        try (PreparedStatement statement = conexion.prepareStatement(consulta)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejo de excepciones apropiado aquí.
        }
    }
}

